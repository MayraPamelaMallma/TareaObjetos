package trabajopracticobjeto1.autos;

import lombok.ToString;

@ToString

public class AutoClasico extends Autos{
    private String marca;
    private String modelo;
    private String color;
    private double precio;
    private Radio radio;

    public AutoClasico(String marca, String modelo, String color, double precio) {
        super(marca, modelo, color, precio);
        this.marca=marca;
        this.modelo= modelo;
        this.color=color;
        this.precio=precio;
    }

    public void agregarRadio(Radio radio){   // para agregar radio 
        this.radio=radio;
    }


}
